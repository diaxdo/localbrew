//
//  ViewController.swift
//  LocalBrew
//
//  Created by Hyo Min Son on 3/16/17.
//  Copyright © 2017 Hyo Min Son. All rights reserved.
//

import UIKit
import MapKit
import CoreLocation

class ViewController: UIViewController {
//    let image = UIImage(named: "localbreeew.png")
    
    let locationManager = CLLocationManager()
    var a: String?
    var b: String?

    var exists = true
//    [{name:BJ, description: blahblahblah, longitude: 123, latitude: 23432}, {name: sdf, description: sfsdf}]
    
    @IBOutlet weak var mapView: MKMapView!

    
    
    @IBAction func zoomButton(_ sender: UIButton) {
    }
    @IBAction func someButton(_ sender: UIButton) {
        mapView.zoomToUserLocation()
        print(mapView.userLocation.location?.coordinate ?? "no coordinate available")
        let curLoc = mapView.userLocation.location
        
        let geocoder = CLGeocoder()
        geocoder.reverseGeocodeLocation(curLoc!, completionHandler: { (placemark, error) in
            if (error != nil) {
                print("some error existed")
            }
            else {
                if let place = placemark?[0] {
                    let locality = place.locality!.replacingOccurrences(of: " ", with: "%20")
//                    print (locality)
                    let urlRequest = URLRequest(url: URL(string: "http://api.brewerydb.com/v2/locations?key=ac444fad7d9ca99f4181d9e8dbaf9e0b&locality=\(locality)")!)
                    let task = URLSession.shared.dataTask(with: urlRequest) { (data, response, error) in
                        if error == nil {
                            do {
                                let json = try JSONSerialization.jsonObject(with: data!, options: .mutableContainers) as! [String: AnyObject]
                                if let data = json["data"] as? [AnyObject] {
                                    for elem in data{
                                        var latitude: Double?
                                        var longitude: Double?
                                        var name: String?
                                        var description: String?
                                        
                                        if let lat = elem["latitude"] as? Double {
//                                            print (lat)
                                            latitude = lat
                                        }
                                        if let long = elem["longitude"] as? Double {
//                                            print(long)
                                            longitude = long
                                        }
                                  
                                        if let brewery = elem["brewery"] as? [String: AnyObject] {
                                            if let n = brewery["name"] as? String {
                                                name = n
                                            }
                                            if let desc = brewery["description"] as? String {
                                                description = desc
                                            }
                                        }
                                        let location = CLLocationCoordinate2DMake(latitude!, longitude!)
                                        let annotation = MKPointAnnotation()
                                        annotation.coordinate = location
                                        annotation.title = name
                                        annotation.subtitle = description
                                        self.mapView.addAnnotation(annotation)
                                    }
                                }
                                if let _ = json["error"]{
                                    self.exists = false
                                }
//                                DispatchQueue.main.async {
//                                    if self.exists{
//                                        print(self.a)
//                                        print(self.b)
//                                    }
//                                    else{
//                                        print("hello world")
//                                    }
//                                }
                            }
                            catch let jsonError {
                                print(jsonError.localizedDescription)
                            }
                        }
                    }
                    task.resume()
                }
            }
        })
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        locationManager.delegate = self
        locationManager.requestAlwaysAuthorization()

        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
}

extension MKMapView {
    func zoomToUserLocation() {
        guard let coordinate = userLocation.location?.coordinate else { return }
        let region = MKCoordinateRegionMakeWithDistance(coordinate, 10000, 10000)
        setRegion(region, animated: true)
    }      
}
extension ViewController: CLLocationManagerDelegate {
    func locationManager(_ manager: CLLocationManager, didChangeAuthorization status: CLAuthorizationStatus) {
        mapView.showsUserLocation = (status == .authorizedAlways)
    }
}
