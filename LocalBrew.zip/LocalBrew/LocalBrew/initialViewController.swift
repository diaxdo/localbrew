//
//  initialViewController.swift
//  LocalBrew
//
//  Created by Hyo Min Son on 3/17/17.
//  Copyright © 2017 Hyo Min Son. All rights reserved.
//

import Foundation
import UIKit

class initialViewController: UIViewController {
    let image = UIImage(named: "logonew.png")
    
    @IBOutlet weak var logoView: UIImageView!
    @IBOutlet weak var largeButton: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        logoView.image = image
//        largeButton.setImage(image, for: UIControlState.normal)
               // Do any additional setup after loading the view, typically from a nib.
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

}
